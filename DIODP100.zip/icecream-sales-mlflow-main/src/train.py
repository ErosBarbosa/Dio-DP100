import argparse
import pandas as pd
import mlflow
import mlflow.sklearn
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, r2_score

def main(data_path):
    # Habilita autolog do MLflow
    mlflow.sklearn.autolog()

    # Carrega o dataset
    df = pd.read_csv(data_path)
    X = df[['temperature']]
    y = df['sales']

    # Divide em treino e teste
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Inicia a run no MLflow
    with mlflow.start_run(run_name="icecream-regression-model"):
        model = LinearRegression()
        model.fit(X_train, y_train)

        y_pred = model.predict(X_test)

        mae = mean_absolute_error(y_test, y_pred)
        r2 = r2_score(y_test, y_pred)

        print(f"MAE: {mae}")
        print(f"R2: {r2}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_path', type=str, default='../data/icecream_data.csv', 
                        help="Caminho do arquivo CSV com dados de sorvete.")
    args = parser.parse_args()

    main(args.data_path)
