import mlflow
import mlflow.sklearn
import argparse

def main(temperature):
    # Carrega o último modelo do MLflow (dependendo do seu tracking URI)
    model_uri = "mlruns/0/<SEU_EXPERIMENTO_ID>/artifacts/model"  # Exemplo local
    # Ou se tiver registrado no MLflow Model Registry:
    # model_uri = "models:/meu_modelo_de_sorvete/Production"
    
    model = mlflow.sklearn.load_model(model_uri)
    
    sales_pred = model.predict([[temperature]])
    print(f"Previsão de vendas de sorvete para {temperature}°C: {sales_pred[0]:.2f}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--temperature', type=float, default=30.0, help="Temperatura para a previsão")
    args = parser.parse_args()

    main(args.temperature)
