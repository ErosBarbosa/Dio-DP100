pip install -r src/requirements.txt

# Previsão de Vendas de Sorvete 🍦

Este projeto faz parte do desafio proposto pela DIO. Nosso objetivo foi criar um modelo de regressão para prever quantos sorvetes serão vendidos com base na temperatura do dia.

## Estrutura do Projeto

icecream-sales-mlflow/
├── inputs/
│   └── sentences.txt
├── data/
│   └── icecream_data.csv
├── notebooks/
│   └── 01_training.ipynb
├── src/
│   ├── train.py
│   ├── predict.py
│   └── requirements.txt
├── readme.md
└── .gitignore


- **`inputs/sentences.txt`**: Contém sentenças escritas por mim, demonstrando aprendizado.
- **`data/icecream_data.csv`**: Dataset sintético com `temperature` e `sales`.
- **`notebooks/01_training.ipynb`**: Notebook onde testei o modelo interativamente.
- **`src/train.py`**: Script para treinar o modelo usando MLflow.
- **`src/predict.py`**: Script para gerar previsões usando o modelo treinado.
- **`src/requirements.txt`**: Dependências do projeto.

## Como Rodar

1. Clonar o repositório.
2. Instalar dependências:
    ```bash
    pip install -r src/requirements.txt
    ```
3. Executar o treinamento:
    ```bash
    python src/train.py --data_path data/icecream_data.csv
    ```
4. Executar a previsão:
    ```bash
    python src/predict.py --temperature 32
    ```

## Prints de Execução
(Insira aqui capturas de tela do MLflow mostrando runs, métricas, gráficos etc.)

## Insights e Possibilidades

- **Temperatura** afeta diretamente as vendas. Percebemos que dias quentes (>30°C) geram pico de vendas.
- A **linha de regressão** é bem intuitiva, pois a cada grau adicional, vemos um acréscimo de vendas.
- Podemos **melhorar** o modelo adicionando mais variáveis (como dia da semana, feriados etc.).

## Observações

- Este projeto pode ser aprimorado com dados reais, envio para pipeline no Azure Machine Learning e implantação via endpoint para previsões em tempo real.
- Também podemos usar [Azure ML + MLflow integration](https://learn.microsoft.com/pt-br/azure/machine-learning/how-to-use-mlflow) para registrar modelos e fazer deploy em containers ou web services.

